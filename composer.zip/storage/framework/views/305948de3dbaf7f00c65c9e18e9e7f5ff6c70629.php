<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <th scope="row"><?php echo e($loop->index + 1); ?></th>
    <td><?php echo e($product->name ?? ''); ?></td>
    <td><?php echo e($product->details ?? ''); ?></td>
    <td>
        <button class="btn btn-info" onClick="showProductEditModal('<?php echo e($product->id); ?>','<?php echo e($product->name); ?>','<?php echo e($product->details); ?>')">
            Edit
    </button>
        <button class="btn btn-danger" onClick="productDelete('<?php echo e($product->id); ?>')" >Delete</button>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\laravel-ajax\resources\views/table.blade.php ENDPATH**/ ?>